package Problem_Statement_7_2;

public class AgeIsNotWithInTheRangeException extends Exception{

}
